﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TelephoneNumbers
{
    public partial class frmTelephoneNumbers : Form
    {
        public frmTelephoneNumbers()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            String alphamnumeric = txtAlphanumeric.Text;
            StringBuilder sb = new StringBuilder();   
            foreach(char c in alphamnumeric.ToCharArray())
            {
                if (char.IsDigit(c))
                {
                    sb.Append(c);
                }
                else if(char.IsLetter(c))
                {
                    if(c.ToString().ToUpper() == "A" || c.ToString().ToUpper() == "B" || c.ToString().ToUpper() == "C")
                    {
                        sb.Append(2);
                    }
                    else if(c.ToString().ToUpper() == "D" || c.ToString().ToUpper() == "E" || c.ToString().ToUpper() == "F")
                    {
                        sb.Append(3);
                    }
                    else if (c.ToString().ToUpper() == "G" || c.ToString().ToUpper() == "H" || c.ToString().ToUpper() == "I")
                    {
                        sb.Append(4);
                    }
                    else if (c.ToString().ToUpper() == "J" || c.ToString().ToUpper() == "K" || c.ToString().ToUpper() == "L")
                    {
                        sb.Append(5);
                    }
                    else if (c.ToString().ToUpper() == "M" || c.ToString().ToUpper() == "N" || c.ToString().ToUpper() == "O")
                    {
                        sb.Append(6);
                    }
                    else if (c.ToString().ToUpper() == "P" || c.ToString().ToUpper() == "Q" || c.ToString().ToUpper() == "R" || c.ToString().ToUpper() == "S")
                    {
                        sb.Append(7);
                    }
                    else if (c.ToString().ToUpper() == "T" || c.ToString().ToUpper() == "U" || c.ToString().ToUpper() == "V")
                    {
                        sb.Append(8);
                    }
                    else if (c.ToString().ToUpper() == "W" || c.ToString().ToUpper() == "X" || c.ToString().ToUpper() == "Y" || c.ToString().ToUpper() == "Z")
                    {
                        sb.Append(9);
                    }
                }
                else
                {
                    sb.Append(c);
                }
            }

            txtNumericOnly.Text = sb.ToString();
            txtAlphanumeric.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
