﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculateLetterGrade
{
    public partial class frmCalculateLetterGrade : Form
    {
        public frmCalculateLetterGrade()
        {
            InitializeComponent();
        }
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int numberInput = Convert.ToInt32(txtNumericGrade.Text);

            if (numberInput >= 90 && numberInput <= 100)
            {
                lblLetterGrade.Text = "A";
            }
            else if (numberInput >= 80 && numberInput <= 89)
            {
                lblLetterGrade.Text = "B";
            }
            else if (numberInput >= 70 && numberInput <= 79)
            {
                lblLetterGrade.Text = "C";
            }
            else if (numberInput >= 60 && numberInput <= 69)
            {
                lblLetterGrade.Text = "D";
            }
            else if (numberInput < 60)
            {
                lblLetterGrade.Text = "F";
            }
            else
            {
                MessageBox.Show("You Input wrong number pls input between 0 - 100");
                txtNumericGrade.Focus();
            }

            txtNumericGrade.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
