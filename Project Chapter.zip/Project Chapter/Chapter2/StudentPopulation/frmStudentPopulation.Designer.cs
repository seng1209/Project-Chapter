﻿namespace StudentPopulation
{
    partial class frmStudentPopulation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtNumberOfStudentToday = new System.Windows.Forms.TextBox();
            this.txtAnnualGrowthRate = new System.Windows.Forms.TextBox();
            this.txtNumberOfYears = new System.Windows.Forms.TextBox();
            this.txtProjectNumberOfStudents = new System.Windows.Forms.TextBox();
            this.btnProject = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Number of student today";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Annual growth rate";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Number of years";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 147);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(171, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Projects number of students";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtNumberOfStudentToday
            // 
            this.txtNumberOfStudentToday.Location = new System.Drawing.Point(252, 21);
            this.txtNumberOfStudentToday.Name = "txtNumberOfStudentToday";
            this.txtNumberOfStudentToday.Size = new System.Drawing.Size(143, 22);
            this.txtNumberOfStudentToday.TabIndex = 0;
            this.txtNumberOfStudentToday.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtAnnualGrowthRate
            // 
            this.txtAnnualGrowthRate.Location = new System.Drawing.Point(252, 62);
            this.txtAnnualGrowthRate.Name = "txtAnnualGrowthRate";
            this.txtAnnualGrowthRate.Size = new System.Drawing.Size(143, 22);
            this.txtAnnualGrowthRate.TabIndex = 1;
            this.txtAnnualGrowthRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtNumberOfYears
            // 
            this.txtNumberOfYears.Location = new System.Drawing.Point(252, 103);
            this.txtNumberOfYears.Name = "txtNumberOfYears";
            this.txtNumberOfYears.Size = new System.Drawing.Size(143, 22);
            this.txtNumberOfYears.TabIndex = 2;
            this.txtNumberOfYears.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtProjectNumberOfStudents
            // 
            this.txtProjectNumberOfStudents.Location = new System.Drawing.Point(252, 144);
            this.txtProjectNumberOfStudents.Name = "txtProjectNumberOfStudents";
            this.txtProjectNumberOfStudents.ReadOnly = true;
            this.txtProjectNumberOfStudents.Size = new System.Drawing.Size(143, 22);
            this.txtProjectNumberOfStudents.TabIndex = 7;
            this.txtProjectNumberOfStudents.TabStop = false;
            this.txtProjectNumberOfStudents.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnProject
            // 
            this.btnProject.Location = new System.Drawing.Point(80, 199);
            this.btnProject.Name = "btnProject";
            this.btnProject.Size = new System.Drawing.Size(94, 64);
            this.btnProject.TabIndex = 3;
            this.btnProject.Text = "&Project Student Population";
            this.btnProject.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(262, 199);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(94, 64);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            // 
            // frmStudentPopulation
            // 
            this.AcceptButton = this.btnProject;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(436, 287);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnProject);
            this.Controls.Add(this.txtProjectNumberOfStudents);
            this.Controls.Add(this.txtNumberOfYears);
            this.Controls.Add(this.txtAnnualGrowthRate);
            this.Controls.Add(this.txtNumberOfStudentToday);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmStudentPopulation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student Population";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtNumberOfStudentToday;
        private System.Windows.Forms.TextBox txtAnnualGrowthRate;
        private System.Windows.Forms.TextBox txtNumberOfYears;
        private System.Windows.Forms.TextBox txtProjectNumberOfStudents;
        private System.Windows.Forms.Button btnProject;
        private System.Windows.Forms.Button btnExit;
    }
}

